
const usename  = 'username';
const password = 'password';

const test_usename  = 'tp2011002gl';
const test_password = 'cbPBa_test';


const tool = (() => {
    // window.alert('アプリ開いたね！');

    setTimeout(()=>{
        //初期ボタン画面
        if( document.getElementById('form1:logout') ){
            (async()=>{
                const logout_button = await document.getElementById('form1:logout')
                await logout_button.click()
            })()
        }

        //ログイン画面
        if( document.getElementById('form1:login') ){
            (async()=>{
                const usename_input = await document.getElementById('form1:htmlUserId')
                const password_input = await document.getElementById('form1:htmlPassword')
                const login_button = await document.getElementById('form1:login')
                usename_input.value = await usename
                password_input.value = await password
                await login_button.click()
            })()
        }

        //ログイン後メニュー画面
        if( document.getElementById('header') ){
            setInterval(() => {
                window.alert('このページを開いてから10分以上経過しました。\n記入した内容が失われるかもしれません。');
            }, 900000);
        }
    },100)
})();


// https://t-po.tais.ac.jp/up/faces/login/Com00504A.jsp